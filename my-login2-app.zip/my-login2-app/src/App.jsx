import Navbar from './components/Navbar'
import { Outlet } from 'react-router-dom'
import Login from './pages/Login'

function App() {
  return (
    <>
      <Navbar />
      <Outlet />
    </>
  )
}

export default App
