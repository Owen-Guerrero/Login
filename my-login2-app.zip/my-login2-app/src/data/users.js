export const usersData = [
  {
    id: 1,
    name: 'Juan',
    lastName: 'Pérez',
    dni: '12345678',
    phone: '999999999',
    email: 'juan@ulima.com',
    password: '123456',
  },
  {
    id: 2,
    name: 'María',
    lastName: 'Gómez',
    dni: '87654321',
    phone: '888888888',
    email: 'maria@nose.com',
    password: 'abcdef',
  },
  {
    id: 3,
    name: 'Daniel',
    lastName: 'Espinoza',
    dni: '12345678',
    phone: '696969696',
    email: 'deg@espinoza.com',
    password: 'degoteo',
  },
]
