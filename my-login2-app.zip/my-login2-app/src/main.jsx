import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { createBrowserRouter, RouterProvider } from 'react-router-dom'
import App from './App.jsx'
import AuthProvider from './contexts/AuthContext.jsx'
import Login from './routes/Login.jsx'
import Register from './routes/Register.jsx'
import PasswordRecovery from './routes/PasswordRecovery.jsx'
import UserDashboard from './routes/UserDashboard.jsx'
import OrderDetail from './routes/OrderDetail.jsx'
import EditProfile from './routes/EditProfile.jsx'
import ChangePassword from './routes/ChangePassword.jsx'

const router = createBrowserRouter([
  {
    path: '/',
    element: <App />,
    children: [
      { path: 'login', element: <Login /> },
      { path: 'register', element: <Register /> },
      { path: 'password-recovery', element: <PasswordRecovery /> },
      { path: 'dashboard', element: <UserDashboard /> },
      { path: 'orders/:orderId', element: <OrderDetail /> },
      { path: 'profile/edit', element: <EditProfile /> },
      { path: 'profile/change-password', element: <ChangePassword /> },
    ],
  },
])

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <AuthProvider>
      <RouterProvider router={router} />
    </AuthProvider>
  </StrictMode>
)