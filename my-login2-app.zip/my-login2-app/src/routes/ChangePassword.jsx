import ChangePasswordPage from '../pages/ChangePassword';

const ChangePassword = () => {
    return (
        <ChangePasswordPage />
    );
}

export default ChangePassword;