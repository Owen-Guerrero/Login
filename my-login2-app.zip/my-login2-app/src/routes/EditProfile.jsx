import EditProfilePage  from "../pages/EditProfile"

const EditProfile = () => {
    return (
        <EditProfilePage />
    );
}

export default EditProfile;