import LoginPage from '../pages/Login';

const Login = () => {
    return (
        <LoginPage />
    );
}
export default Login;