import OrderDetailPage from '../pages/OrderDetail';

const OrderDetail = () => {
    return (
        <OrderDetailPage />
    );
}

export default OrderDetail;