import PasswordRecoveryPage from '../pages/PasswordRecovery';

const PasswordRecovery = () => {
    return (
        <PasswordRecoveryPage />
    );
}

export default PasswordRecovery;