import RegisterPage from '../pages/Register';

const Register = () => {
    return (
        <RegisterPage />
    );
}

export default Register;