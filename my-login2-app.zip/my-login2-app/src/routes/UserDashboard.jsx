import UserDashboardPage from '../pages/UserDashboard';

const UserDashboard = () => {
    return (
        <UserDashboardPage />
    );
}

export default UserDashboard;